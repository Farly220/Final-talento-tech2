export type EnergyData = {
  entity: string;
  year: number;
  wind_generation_twh: number;
  solar_generation_twh: number;
  hydro_generation_twh: number;
  biofuel_production_twh: number;
  geothermal_generation_twh: number;
  share_electricity_renewables_pct: number;
  share_electricity_wind_pct: number;
  share_electricity_solar_pct: number;
  share_electricity_hydro_pct: number;
  cumulative_wind_capacity_gw: number;
  cumulative_solar_capacity_gw: number;
  cumulative_geothermal_capacity_gw: number;
  renewable_energy_consumption_twh: number;
  fossil_fuel_consumption_twh: number;
};
