import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-renewable-energy-data.ts';