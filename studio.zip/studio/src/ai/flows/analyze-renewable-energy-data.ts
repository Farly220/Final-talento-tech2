'use server';
/**
 * @fileOverview Analyzes renewable energy data to highlight significant uptakes and downfalls.
 *
 * - analyzeRenewableEnergyData - A function that analyzes the renewable energy data.
 * - AnalyzeRenewableEnergyDataInput - The input type for the analyzeRenewableEnergyData function.
 * - AnalyzeRenewableEnergyDataOutput - The return type for the analyzeRenewableEnergyData function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeRenewableEnergyDataInputSchema = z.object({
  datasetUrl: z
    .string()
    .describe(
      'URL of the renewable energy dataset in CSV format.  Must be accessible over the internet.'
    ),
});
export type AnalyzeRenewableEnergyDataInput = z.infer<typeof AnalyzeRenewableEnergyDataInputSchema>;

const AnalyzeRenewableEnergyDataOutputSchema = z.object({
  analysis: z.string().describe('The analysis of significant uptakes and downfalls in renewable energy data.'),
});
export type AnalyzeRenewableEnergyDataOutput = z.infer<typeof AnalyzeRenewableEnergyDataOutputSchema>;

export async function analyzeRenewableEnergyData(input: AnalyzeRenewableEnergyDataInput): Promise<AnalyzeRenewableEnergyDataOutput> {
  return analyzeRenewableEnergyDataFlow(input);
}

const analyzeDataPrompt = ai.definePrompt({
  name: 'analyzeDataPrompt',
  input: {schema: AnalyzeRenewableEnergyDataInputSchema},
  output: {schema: AnalyzeRenewableEnergyDataOutputSchema},
  prompt: `You are an expert data analyst specializing in renewable energy trends.

  Analyze the provided renewable energy dataset, focusing on identifying significant uptakes and downfalls in specific regions, dates, and technologies. Provide a concise summary of your findings.  The dataset is located at the following URL: {{datasetUrl}}.
  Limit yourself to at most 500 words.
  `,
});

const analyzeRenewableEnergyDataFlow = ai.defineFlow(
  {
    name: 'analyzeRenewableEnergyDataFlow',
    inputSchema: AnalyzeRenewableEnergyDataInputSchema,
    outputSchema: AnalyzeRenewableEnergyDataOutputSchema,
  },
  async input => {
    const {output} = await analyzeDataPrompt(input);
    return output!;
  }
);
