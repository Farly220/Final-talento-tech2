import EnergyCalculatorClient from "@/components/calculator/energy-calculator-client";
import { promises as fs } from 'fs';
import path from 'path';
import type { EnergyData } from "@/lib/types";

export default async function CalculatorPage() {
    let data: EnergyData[] = [];
    try {
        const dataPath = path.join(process.cwd(), 'public/data/renewable-energy-data.json');
        const fileContents = await fs.readFile(dataPath, 'utf8');
        data = JSON.parse(fileContents);
    } catch (error) {
        console.error('Failed to load energy data:', error);
    }
    
    const countries = [...new Set(data.map(item => item.entity))].sort();

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold tracking-tight font-headline">
                Calculadora de Energía Renovable
            </h1>
            <EnergyCalculatorClient data={data} countries={countries} />
        </div>
    );
}
