import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import { Sun, Wind, Waves, Mountain } from "lucide-react";

const energySources = [
  {
    id: "solar",
    title: "Energía Solar",
    icon: Sun,
    description: "Aprovechamiento de la energía del sol a través de paneles fotovoltaicos (PV) o energía solar concentrada.",
    details: "La energía solar es un recurso vasto e inagotable. Se está convirtiendo en una de las formas de electricidad más baratas en muchas partes del mundo. Se puede implementar a escalas que van desde pequeñas instalaciones en tejados hasta enormes granjas solares a escala de servicios públicos.",
    imageId: "solar-panels"
  },
  {
    id: "wind",
    title: "Energía Eólica",
    icon: Wind,
    description: "Conversión de la energía cinética del viento en electricidad mediante aerogeneradores.",
    details: "La energía eólica es una fuente de energía limpia que no produce contaminación del aire ni del agua. Los parques eólicos terrestres y marinos son capaces de generar cantidades sustanciales de electricidad, contribuyendo significativamente a la red eléctrica en muchos países.",
    imageId: "wind-turbines"
  },
  {
    id: "hydro",
    title: "Energía Hidroeléctrica",
    icon: Waves,
    description: "Generación de electricidad a partir de la fuerza gravitacional del agua que cae o fluye.",
    details: "La energía hidroeléctrica es una de las fuentes de energía renovable más antiguas y grandes. Generalmente es fiable y se puede despachar rápidamente, pero los proyectos a gran escala pueden tener importantes impactos ambientales y sociales.",
    imageId: "hydro-dam"
  },
  {
    id: "geothermal",
    title: "Energía Geotérmica",
    icon: Mountain,
    description: "Utilización del calor del núcleo de la Tierra para generar electricidad o para calefacción directa.",
    details: "La energía geotérmica proporciona una fuente de energía estable y constante, independiente de las condiciones climáticas. Tiene una pequeña huella física en el paisaje y altos factores de capacidad, lo que la convierte en una fuente de energía de carga base fiable.",
    imageId: "geothermal-plant"
  }
];

export default function InfoPage() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight font-headline">
          Acerca de la Energía Renovable
        </h1>
        <p className="text-muted-foreground">
          Aprende sobre las diferentes fuentes de energía limpia que están impulsando nuestro futuro.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {energySources.map(source => {
          const image = PlaceHolderImages.find(img => img.id === source.imageId);
          return (
            <Card key={source.id} className="overflow-hidden">
              {image && (
                <div className="relative h-48 w-full">
                  <Image
                    src={image.imageUrl}
                    alt={image.description}
                    data-ai-hint={image.imageHint}
                    fill
                    className="object-cover"
                  />
                </div>
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <source.icon className="h-6 w-6 text-primary" />
                  {source.title}
                </CardTitle>
                <CardDescription>{source.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{source.details}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
