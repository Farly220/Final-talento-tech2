import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link as LinkIcon } from "lucide-react";
import Link from 'next/link';

const sources = [
    {
        name: "Conjunto de datos de Energía Renovable a Nivel Mundial (1965-2022)",
        url: "https://www.kaggle.com/datasets/belayethossainds/renewable-energy-world-wide-19652022",
        description: "El conjunto de datos principal utilizado para todas las visualizaciones y cálculos en esta aplicación, proporcionado por Our World in Data."
    },
    {
        name: "W3Schools",
        url: "https://www.w3schools.com/",
        description: "Un recurso valioso para tutoriales y referencias de desarrollo web."
    },
    {
        name: "DesarrolloWeb.com",
        url: "https://desarrolloweb.com/manuales/css3.html",
        description: "Proveedor de un manual completo sobre CSS3 para el estilizado."
    },
    {
        name: "Amazon Web Services (AWS)",
        url: "https://aws.amazon.com/es/what-is/javascript/",
        description: "Recurso informativo sobre el lenguaje de programación JavaScript."
    },
    {
        name: "GitHub",
        url: "https://github.com/",
        description: "Plataforma para alojar y colaborar en código."
    }
]

export default function SourcesPage() {
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold tracking-tight font-headline">
                Fuentes de Datos y Recursos
            </h1>
            <p className="text-muted-foreground">
                Este proyecto es posible gracias a los siguientes conjuntos de datos, herramientas y recursos.
            </p>
            <div className="space-y-4">
                {sources.map((source) => (
                    <Card key={source.name}>
                        <CardHeader>
                            <CardTitle>
                                <Link href={source.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-primary transition-colors">
                                    {source.name}
                                    <LinkIcon className="h-4 w-4" />
                                </Link>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p>{source.description}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
