import { promises as fs } from 'fs';
import path from 'path';
import type { EnergyData } from '@/lib/types';
import DashboardClient from '@/components/dashboard/dashboard-client';
import { notFound } from 'next/navigation';

export default async function DashboardPage() {
  let data: EnergyData[] = [];
  try {
    const dataPath = path.join(process.cwd(), 'public/data/renewable-energy-data.json');
    const fileContents = await fs.readFile(dataPath, 'utf8');
    data = JSON.parse(fileContents);
  } catch (error) {
    console.error('Failed to load energy data:', error);
    // Depending on the desired behavior, you could show an error message
    // or fall back to an empty state. For now, we'll let it render with no data.
    // In a real app, you might want better error handling here.
  }

  if (!data.length) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <p className="text-muted-foreground">No se pudieron cargar los datos de energía.</p>
      </div>
    );
  }

  const countries = [...new Set(data.map(item => item.entity))].sort();

  return <DashboardClient data={data} countries={countries} />;
}
