import { promises as fs } from 'fs';
import path from 'path';
import type { EnergyData } from '@/lib/types';
import DataTableClient from '@/components/data-table-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default async function DataPage() {
    let data: EnergyData[] = [];
    try {
        const dataPath = path.join(process.cwd(), 'public/data/renewable-energy-data.json');
        const fileContents = await fs.readFile(dataPath, 'utf8');
        data = JSON.parse(fileContents);
    } catch (error) {
        console.error('Failed to load energy data:', error);
    }
    
    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold tracking-tight font-headline">
                Datos Globales de Energía Renovable
            </h1>
            <Card>
                <CardHeader>
                    <CardTitle>Explorador de Conjunto de Datos</CardTitle>
                    <CardDescription>
                        Navega por el conjunto de datos históricos de energía renovable global. Los datos que se muestran aquí son una muestra.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                   {data.length > 0 ? <DataTableClient data={data} /> : <p>No se pudieron cargar los datos.</p>}
                </CardContent>
            </Card>
        </div>
    );
}
