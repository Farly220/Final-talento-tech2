"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface DashboardFiltersProps {
  countries: string[];
  selectedCountry: string;
  onCountryChange: (country: string) => void;
  years: number[];
  selectedYear: number;
  onYearChange: (year: number) => void;
}

export default function DashboardFilters({
  countries,
  selectedCountry,
  onCountryChange,
  years,
  selectedYear,
  onYearChange,
}: DashboardFiltersProps) {
  return (
    <div className="flex gap-4">
      <Select value={selectedCountry} onValueChange={onCountryChange}>
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Seleccionar País" />
        </SelectTrigger>
        <SelectContent>
          {countries.map((country) => (
            <SelectItem key={country} value={country}>
              {country}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={String(selectedYear)} onValueChange={(val) => onYearChange(Number(val))}>
        <SelectTrigger className="w-[120px]">
          <SelectValue placeholder="Seleccionar Año" />
        </SelectTrigger>
        <SelectContent>
          {years.map((year) => (
            <SelectItem key={year} value={String(year)}>
              {year}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
