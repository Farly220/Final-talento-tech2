"use client"

import * as React from "react"
import { Pie, PieChart, Tooltip } from "recharts"
import type { EnergyData } from "@/lib/types"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"

interface SharePieChartProps {
    data: EnergyData | undefined;
}

export default function SharePieChart({ data }: SharePieChartProps) {
  const chartData = data ? [
    { type: "wind", value: data.share_electricity_wind_pct, fill: "var(--color-wind)" },
    { type: "solar", value: data.share_electricity_solar_pct, fill: "var(--color-solar)" },
    { type: "hydro", value: data.share_electricity_hydro_pct, fill: "var(--color-hydro)" },
  ] : [];

  const otherRenewables = data ? data.share_electricity_renewables_pct - (data.share_electricity_wind_pct + data.share_electricity_solar_pct + data.share_electricity_hydro_pct) : 0;
  if(otherRenewables > 0.1) {
    chartData.push({ type: "other", value: parseFloat(otherRenewables.toFixed(2)), fill: "var(--color-other)" });
  }

  const chartConfig = {
    value: {
      label: "%",
    },
    wind: {
      label: "Eólica",
      color: "hsl(var(--chart-1))",
    },
    solar: {
      label: "Solar",
      color: "hsl(var(--chart-2))",
    },
    hydro: {
      label: "Hidroeléctrica",
      color: "hsl(var(--chart-3))",
    },
    other: {
      label: "Otras",
      color: "hsl(var(--chart-4))",
    }
  }

  return (
    <Card className="flex flex-col">
      <CardHeader>
        <CardTitle>Participación de Renovables en Electricidad</CardTitle>
        <CardDescription>
          Participación total renovable: {data?.share_electricity_renewables_pct?.toFixed(1) || 'N/A'}% en {data?.year || 'N/A'}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        <ChartContainer
          config={chartConfig}
          className="mx-auto aspect-square max-h-[250px]"
        >
          <PieChart>
            <Tooltip content={<ChartTooltipContent nameKey="type" hideLabel />} />
            <Pie data={chartData} dataKey="value" nameKey="type" innerRadius={60} />
            <ChartLegend
              content={<ChartLegendContent nameKey="type" />}
              className="-translate-y-2 flex-wrap gap-2 [&>*]:basis-1/4 [&>*]:justify-center"
            />
          </PieChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
