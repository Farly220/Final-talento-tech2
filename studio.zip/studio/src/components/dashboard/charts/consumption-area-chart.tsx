"use client"

import type { EnergyData } from "@/lib/types"
import { Area, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"

interface ConsumptionAreaChartProps {
  data: EnergyData[];
}

export default function ConsumptionAreaChart({ data }: ConsumptionAreaChartProps) {
  const chartConfig = {
    renewable: {
      label: "Renovable (TWh)",
      color: "hsl(var(--chart-1))",
    },
    fossil: {
      label: "Combustible Fósil (TWh)",
      color: "hsl(var(--chart-3))",
    },
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Consumo de Energía: Renovable vs. Combustible Fósil</CardTitle>
        <CardDescription>
          Comparación del consumo de energía para {data[0]?.entity || 'N/A'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
          <AreaChart
            accessibilityLayer
            data={data}
            margin={{
              left: 12,
              right: 12,
            }}
          >
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="year"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
            />
            <YAxis
                tickFormatter={(value) => {
                    if (typeof value === 'number' && value >= 1000) {
                        return `${value / 1000}k`;
                    }
                    return value.toString();
                }}
            />
            <Tooltip content={<ChartTooltipContent />} />
            <ChartLegend content={<ChartLegendContent />} />
            <Area
              dataKey="renewable_energy_consumption_twh"
              type="natural"
              fill="var(--color-renewable)"
              fillOpacity={0.4}
              stroke="var(--color-renewable)"
              stackId="a"
              name="renewable"
            />
            <Area
              dataKey="fossil_fuel_consumption_twh"
              type="natural"
              fill="var(--color-fossil)"
              fillOpacity={0.4}
              stroke="var(--color-fossil)"
              stackId="a"
              name="fossil"
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
