"use client"

import type { EnergyData } from "@/lib/types"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltipContent,
} from "@/components/ui/chart"

interface ProductionBarChartProps {
  data: EnergyData | undefined;
}

export default function ProductionBarChart({ data }: ProductionBarChartProps) {
  const chartData = data ? [
    { source: "Eólica", value: data.wind_generation_twh, fill: "var(--color-wind)" },
    { source: "Solar", value: data.solar_generation_twh, fill: "var(--color-solar)" },
    { source: "Hidroeléctrica", value: data.hydro_generation_twh, fill: "var(--color-hydro)" },
    { source: "Biocombustible", value: data.biofuel_production_twh, fill: "var(--color-biofuel)" },
    { source: "Geotérmica", value: data.geothermal_generation_twh, fill: "var(--color-geothermal)" },
  ] : [];

  const chartConfig = {
    value: {
      label: "TWh",
    },
    wind: {
      label: "Eólica",
      color: "hsl(var(--chart-1))",
    },
    solar: {
      label: "Solar",
      color: "hsl(var(--chart-2))",
    },
    hydro: {
      label: "Hidroeléctrica",
      color: "hsl(var(--chart-3))",
    },
    biofuel: {
      label: "Biocombustible",
      color: "hsl(var(--chart-4))",
    },
    geothermal: {
      label: "Geotérmica",
      color: "hsl(var(--chart-5))",
    },
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Producción por Fuente</CardTitle>
        <CardDescription>Energía producida (TWh) por cada fuente renovable en {data?.year || 'N/A'}</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
          <BarChart accessibilityLayer data={chartData} margin={{ top: 20 }}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="source"
              tickLine={false}
              tickMargin={10}
              axisLine={false}
            />
            <YAxis />
            <Tooltip cursor={false} content={<ChartTooltipContent />} />
            <Bar dataKey="value" radius={4} />
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
