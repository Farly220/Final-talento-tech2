"use client"

import type { EnergyData } from "@/lib/types"
import { CartesianGrid, Line, LineChart, XAxis, YAxis, Tooltip } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"

interface CapacityLineChartProps {
  data: EnergyData[];
}

export default function CapacityLineChart({ data }: CapacityLineChartProps) {
  const chartConfig = {
    wind: {
      label: "Eólica (GW)",
      color: "hsl(var(--chart-1))",
    },
    solar: {
      label: "Solar (GW)",
      color: "hsl(var(--chart-2))",
    },
    geothermal: {
      label: "Geotérmica (GW)",
      color: "hsl(var(--chart-4))",
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tendencia de Capacidad Instalada</CardTitle>
        <CardDescription>Evolución de la capacidad instalada acumulada para {data[0]?.entity || 'N/A'}</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
          <LineChart
            accessibilityLayer
            data={data}
            margin={{
              left: 12,
              right: 12,
            }}
          >
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="year"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
            />
            <YAxis
              tickFormatter={(value) => `${value} GW`}
            />
            <Tooltip content={<ChartTooltipContent />} />
             <ChartLegend content={<ChartLegendContent />} />
            <Line
              dataKey="cumulative_wind_capacity_gw"
              type="monotone"
              stroke="var(--color-wind)"
              strokeWidth={2}
              dot={false}
              name="wind"
            />
            <Line
              dataKey="cumulative_solar_capacity_gw"
              type="monotone"
              stroke="var(--color-solar)"
              strokeWidth={2}
              dot={false}
              name="solar"
            />
            <Line
              dataKey="cumulative_geothermal_capacity_gw"
              type="monotone"
              stroke="var(--color-geothermal)"
              strokeWidth={2}
              dot={false}
              name="geothermal"
            />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
