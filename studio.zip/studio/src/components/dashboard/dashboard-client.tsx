"use client";

import { useState, useMemo } from "react";
import type { EnergyData } from "@/lib/types";
import DashboardFilters from "./filters";
import ProductionBarChart from "./charts/production-bar-chart";
import SharePieChart from "./charts/share-pie-chart";
import CapacityLineChart from "./charts/capacity-line-chart";
import ConsumptionAreaChart from "./charts/consumption-area-chart";
import AiInsights from "./ai-insights";

interface DashboardClientProps {
  data: EnergyData[];
  countries: string[];
}

export default function DashboardClient({ data, countries }: DashboardClientProps) {
  const [selectedCountry, setSelectedCountry] = useState("World");
  const latestYear = Math.max(...data.map(d => d.year));
  const [selectedYear, setSelectedYear] = useState(latestYear);

  const filteredData = useMemo(() => {
    return data.filter(d => d.entity === selectedCountry);
  }, [data, selectedCountry]);

  const yearData = useMemo(() => {
    return filteredData.find(d => d.year === selectedYear);
  }, [filteredData, selectedYear]);

  const years = useMemo(() => {
    return [...new Set(data.filter(d => d.entity === selectedCountry).map(item => item.year))].sort((a,b) => b-a);
  }, [data, selectedCountry]);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold tracking-tight font-headline">
          Panel de Energía Renovable
        </h1>
        <DashboardFilters
          countries={countries}
          selectedCountry={selectedCountry}
          onCountryChange={setSelectedCountry}
          years={years}
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ProductionBarChart data={yearData} />
        <SharePieChart data={yearData} />
      </div>
      <div className="grid grid-cols-1 gap-6">
        <CapacityLineChart data={filteredData} />
        <ConsumptionAreaChart data={filteredData} />
      </div>
       <div className="grid grid-cols-1 gap-6">
        <AiInsights />
      </div>
    </div>
  );
}
