"use client";

import { useState, useTransition } from "react";
import { analyzeRenewableEnergyData } from "@/ai/flows/analyze-renewable-energy-data";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";

const DATASET_URL = "https://raw.githubusercontent.com/owid/energy-data/master/owid-energy-data.csv";

export default function AiInsights() {
  const [isPending, startTransition] = useTransition();
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalysis = () => {
    startTransition(async () => {
      setError(null);
      setAnalysis(null);
      try {
        const result = await analyzeRenewableEnergyData({ datasetUrl: DATASET_URL });
        setAnalysis(result.analysis);
      } catch (e: any) {
        console.error("AI analysis failed:", e);
        setError(e.message || "Ocurrió un error inesperado durante el análisis.");
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Perspectivas de Datos con IA</CardTitle>
        <CardDescription>
          Usa IA para analizar automáticamente el conjunto de datos en busca de tendencias significativas en energía renovable.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={handleAnalysis} disabled={isPending}>
          <Wand2 className="mr-2 h-4 w-4" />
          {isPending ? "Analizando..." : "Generar Perspectivas"}
        </Button>

        {isPending && (
          <div className="space-y-2 pt-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        )}

        {error && (
            <Alert variant="destructive">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Falló el Análisis</AlertTitle>
                <AlertDescription>
                    {error}
                </AlertDescription>
            </Alert>
        )}

        {analysis && (
          <div className="prose prose-sm max-w-none text-foreground dark:prose-invert rounded-lg border bg-secondary/50 p-4">
            <p>{analysis}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
