"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  Sidebar,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  Table,
  Calculator,
  Lightbulb,
  Link as LinkIcon,
  Leaf,
} from "lucide-react";
import { useSidebar } from "@/components/ui/sidebar";

const menuItems = [
  {
    href: "/",
    label: "Panel",
    icon: LayoutDashboard,
  },
  {
    href: "/data",
    label: "Tabla de Datos",
    icon: Table,
  },
  {
    href: "/calculator",
    label: "Calculadora",
    icon: Calculator,
  },
  {
    href: "/info",
    label: "Info Energía",
    icon: Lightbulb,
  },
  {
    href: "/sources",
    label: "Fuentes de Datos",
    icon: LinkIcon,
  },
];

export function AppSidebar() {
  const pathname = usePathname();
  const { state } = useSidebar();
  
  return (
    <Sidebar>
      <SidebarHeader>
        <div className="inline-flex items-center gap-2">
          <Leaf className="text-primary h-6 w-6" />
          {state === 'expanded' && <h1 className="text-xl font-bold font-headline">EcoGauge</h1>}
        </div>
      </SidebarHeader>
      <SidebarMenu>
        {menuItems.map((item) => (
          <SidebarMenuItem key={item.href}>
            <Link href={item.href} passHref>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.label}
              >
                <span>
                  <item.icon />
                  <span>{item.label}</span>
                </span>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
      <SidebarFooter/>
    </Sidebar>
  );
}
