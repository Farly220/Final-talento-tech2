"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import type { EnergyData } from "@/lib/types"

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Zap, Wind } from "lucide-react"

const formSchema = z.object({
  consumption: z.coerce.number().min(1, "El consumo debe ser mayor que 0."),
  country: z.string().min(1, "Por favor seleccione un país."),
})

interface EnergyCalculatorClientProps {
  data: EnergyData[];
  countries: string[];
}

interface CalculationResult {
  renewableKWh: number;
  totalConsumption: number;
  renewableShare: number;
  country: string;
  year: number;
}

export default function EnergyCalculatorClient({ data, countries }: EnergyCalculatorClientProps) {
  const [result, setResult] = useState<CalculationResult | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      consumption: 1000,
      country: "World",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    const countryData = data.filter(d => d.entity === values.country);
    if (!countryData.length) return;

    const latestYearData = countryData.reduce((latest, current) => current.year > latest.year ? current : latest);
    
    const renewableShare = latestYearData.share_electricity_renewables_pct;
    const renewableKWh = (values.consumption * renewableShare) / 100;
    
    setResult({
        renewableKWh,
        totalConsumption: values.consumption,
        renewableShare,
        country: values.country,
        year: latestYearData.year,
    })
  }

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Estima tu Consumo Renovable</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="consumption"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Consumo Mensual Total de Electricidad (kWh)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="ej. 1000" {...field} />
                    </FormControl>
                    <FormDescription>
                      Ingresa tu consumo total de electricidad de tu factura de servicios.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>País / Región</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona una región" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      El cálculo se basará en los últimos datos de esta región.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit">Calcular</Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {result && (
        <Card className="flex flex-col items-center justify-center bg-accent/20">
          <CardHeader className="text-center">
            <CardTitle>Tus Resultados Estimados</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="flex items-center justify-center text-primary">
                <Wind className="h-16 w-16" />
                <Zap className="h-16 w-16" />
            </div>
            <p className="mt-4 text-lg">
              Basado en los datos de {result.country} de {result.year}, aproximadamente
            </p>
            <p className="text-4xl font-bold text-primary my-2">
              {result.renewableKWh.toFixed(1)} kWh
            </p>
            <p className="text-lg">
              de tu consumo de <span className="font-semibold">{result.totalConsumption} kWh</span> podría provenir de fuentes renovables.
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Esto se basa en una participación regional de energía renovable de {result.renewableShare.toFixed(1)}%.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
