"use client"

import * as React from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import type { EnergyData } from "@/lib/types"

const ROWS_PER_PAGE = 10;

export default function DataTableClient({ data }: { data: EnergyData[] }) {
  const [currentPage, setCurrentPage] = React.useState(1);
  const totalPages = Math.ceil(data.length / ROWS_PER_PAGE);
  const startIndex = (currentPage - 1) * ROWS_PER_PAGE;
  const selectedData = data.slice(startIndex, startIndex + ROWS_PER_PAGE);

  const handlePrevious = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  };

  const handleNext = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  };

  const headers: { key: keyof EnergyData; label: string }[] = [
    { key: "entity", label: "Entidad" },
    { key: "year", label: "Año" },
    { key: "wind_generation_twh", label: "Eólica (TWh)" },
    { key: "solar_generation_twh", label: "Solar (TWh)" },
    { key: "hydro_generation_twh", label: "Hidroeléctrica (TWh)" },
    { key: "share_electricity_renewables_pct", label: "Participación Renovable (%)" },
  ];

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {headers.map(header => <TableHead key={header.key}>{header.label}</TableHead>)}
            </TableRow>
          </TableHeader>
          <TableBody>
            {selectedData.map((row, index) => (
              <TableRow key={`${row.entity}-${row.year}-${index}`}>
                {headers.map(header => (
                  <TableCell key={header.key}>{row[header.key]}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-end space-x-2">
        <span className="text-sm text-muted-foreground">
          Página {currentPage} de {totalPages}
        </span>
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={currentPage === 1}
        >
          Anterior
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={currentPage === totalPages}
        >
          Siguiente
        </Button>
      </div>
    </div>
  )
}
