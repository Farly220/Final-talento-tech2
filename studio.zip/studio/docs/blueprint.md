# **App Name**: EcoGauge

## Core Features:

- Renewable Energy Info Page: Display information about various renewable energy sources.
- Data Table Visualization: Display the global renewable energy dataset (1965-2022) in a tabular format.
- Renewable Energy Calculator: Calculate the percentage of renewable energy in total electricity consumption based on user input and the dataset.
- Data Insights Tool: Uses an AI tool to automatically look through the entire data set to highlight regions, specific dates, and specific technologies that show unusual renewable uptakes and downfalls.  Generates prose about these data events.
- Renewable Energy Dashboard: Visualize renewable energy production and consumption data using various charts (bar, pie, line, area).
- Data Filtering: Allow users to filter the dashboard data by region and date.
- Data Source Display: Show source attributions, including the kaggle link (https://www.kaggle.com/datasets/belayethossainds/renewable-energy-world-wide-19652022), the w3schools link (https://www.w3schools.com/), the CSS3 link (https://desarrolloweb.com/manuales/css3.html), the JavaScript link (https://aws.amazon.com/es/what-is/javascript/) and the github link (https://github.com/).

## Style Guidelines:

- Primary color: Teal (#008080) to evoke a sense of environmental awareness and sustainability.
- Background color: Light gray (#F0F0F0) for a clean, modern look.
- Accent color: Yellow-Green (#9ACD32) for highlighting interactive elements and important data points.
- Body and headline font: 'PT Sans', a humanist sans-serif, will give a balance between a modern look and a bit of warmth for readability.
- Use clear and recognizable icons to represent different energy sources and dashboard controls.
- Employ a clean, grid-based layout to organize the data tables and charts effectively.
- Use subtle animations to transition between different views or when updating the charts.